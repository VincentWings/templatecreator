/*
* @Title: Javascript - CKEDITOR - Styles
* @Author: JGuerreiro
* @Date:   2015-02-27 11:32:22
* @Last Modified by:   LSherrington
* @Last Modified time: 2018-07-19 10:51:47
*
*/

CKEDITOR.stylesSet.add( 'THEMENAMEYEAR', [
	
	// Block Styles
	{ name: 'Social Icons', element: 'ul', attributes: { 'class': 'ck-social-icons' } },
	{ name: 'Intro text', element: 'p', attributes: { 'class': 'ck-intro-text' } },
	{ name: 'Headline', element: 'h3', attributes: { 'class': 'ck-headline' } },
	
	// Inline Styles
	{ name: 'Button One', element: 'a', attributes: { 'class': 'ck-button-one' } },
	{ name: 'Button Two', element: 'a', attributes: { 'class': 'ck-button-two' } },
	{ name: 'Capital letter', element: 'span', attributes: { 'class': 'ck-capital-letter' } },
	{ name: 'Quote', element: 'span', attributes: { 'class': 'ck-quote' } },

]);
